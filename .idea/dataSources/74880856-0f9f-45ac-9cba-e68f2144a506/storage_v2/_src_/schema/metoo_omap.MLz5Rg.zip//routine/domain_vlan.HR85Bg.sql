create procedure domain_vlan()
  BEGIN
		select 
			`domain`.`id` AS `id`,`domain`.`addTime` AS `addTime`,`domain`.`deleteStatus` AS `deleteStatus`,
			`domain`.`name` AS `name`,`domain`.`description` AS `description`,`domain`.`group_id` AS `group_id`,
			`domain`.`editDate` AS `editDate`,`vlan`.`id` AS `vlan_id`,`vlan`.`name` AS `vlan_name` 
		from 
			metoo_domain domain
		left join 
			`metoo_vlan` `vlan` 
		on `domain`.`id` = `vlan`.`domain_id`;
	END;

